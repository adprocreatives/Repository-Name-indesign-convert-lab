# InDesign Convert Lab v2.5 — Sharing Edition

**Created By Basheer Parammal · © 2026 adprocreatives.**

One user-facing `.jsx` window combines the two existing conversion workflows:

- **PPTX → editable InDesign (`.indd` and `.idml`)** — PPTX/PDF to InDesign engine v3.4.
- **PDF → editable InDesign (`.indd` and `.idml`)** — hybrid extraction of editable paragraphs, independently movable photos, and linked per-page PDF vector background artwork; no OCR.
- **Current INDD → editable PowerPoint (`.pptx`)** — InDesign to PowerPoint engine v1.1.
- **Choose INDD / IDML → editable PowerPoint (`.pptx`)** — as above, for documents not already open.

## Install on macOS

1. Extract the ZIP. **Keep the files together**.
2. In Adobe InDesign go to **Window → Utilities → Scripts**.
3. Right-click **User** and select **Reveal in Finder**.
4. Copy exactly two items into the **Scripts Panel** folder:
   - `InDesign_Convert_Lab_V2_5.jsx`
   - `InDesign_Convert_Lab_Support` (the **entire** folder, including both engines and their nested support directories)
5. Double-click `InDesign_Convert_Lab_V2_5.jsx` in the InDesign Scripts panel.
6. Pick a conversion mode and the source file (or current InDesign document).
7. On the **Review Conversion** screen, check the selected input, output, options, and preflight messages; click **Start Conversion**.

**Do not copy JSON files into the Scripts Panel.** The converter prepares its own intermediate manifest. You do not need to run a `.command` file.

## Requirements

- An ExtendScript/ScriptUI-capable **Adobe InDesign for macOS**.
- **Python 3** for PPTX/PDF → InDesign (first use requires internet access to install `python-pptx`, `Pillow`, `PyMuPDF` into the tool's private virtual environment).
- **Node.js 18+ / npm** for InDesign → PowerPoint (first use requires internet access to install PptxGenJS/JSZip into the support directory).
- Correct original typefaces installed or activated on the machines opening the converted files. **No font binaries are included.**
- Mac may prompt to allow InDesign to execute the local helper. Confirm only if you trust the script.

## Conversion review window

The first window contains four input controls divided into two groups. After you choose a source, **Review Conversion** becomes enabled. The second window checks that the source and required converter files exist, shows the output location, provides format-specific settings, and requires a deliberate **Start Conversion** click. It does not modify the input file.

**Preflight verifies file and support paths, not installed Python/Node versions.** The respective helper checks runtime dependencies when conversion starts and writes its own log on failure.

## Output locations

- **PPTX/PDF → InDesign:** next to your selected input in `[input name]_InDesign_Ready/`. Files include `[input name]_Converted.indd`, `.idml`, conversion report, manifest, images, font matches, and references.
- **InDesign → PPTX:** inside `[document name]_PowerPoint_Export/` under the output folder you select. Files include `[document name]_Editable.pptx` and optionally `[document name]_Visual_Reference.pptx`, plus font reports, `TEXT_EXPORT_AUDIT.txt`, manifest and conversion logs.

## Limits to understand before using

- Editable text, photos, basic shapes, and supported paths are reconstructed; **pixel-identical, fully editable conversion is not guaranteed** in either direction.
- Complex PDF transparencies and gradient shadings are kept as **linked PDF vector artwork**, not converted into individually editable InDesign gradient controls. Selected photo images are individually movable when the mask is safe to extract.
- InDesign effects unsupported by PowerPoint become **separate PNG object fallbacks**, not a wholly flattened PPTX page. Source font family names are referenced but not embedded in the PPTX.
- PDF scan-only text needs separate OCR; this tool does not perform OCR.
- PDF mode may optionally check only **font family names** through Google Fonts for lookup; no PDF document is uploaded.
- Inspect exported layouts, masks, fonts and text overset before final delivery.

## Troubleshooting

**PPTX/PDF → INDD:** check `~/Library/Application Support/BP_PPTX_PDF_to_InDesign/prepare.log` and `InDesign_import_report.txt` in the result folder.

**INDD/IDML → PPTX:** check `run.log`, `TEXT_EXPORT_AUDIT.txt`, `CONVERSION_REPORT.txt` and `EXPORT_WARNINGS.txt` inside its export folder. If text is absent in PowerPoint, verify that the text exists as actual editable InDesign text (rather than outlined or raster text).

For long documents, allow the InDesign-to-PowerPoint builder to finish. The workflow executes on your Mac; no cloud conversion service is provided.

## Distribution

The Original Edition contains readable source for internal customization. The Sharing Edition packs its `.jsx` entrypoints to discourage casual editing, but **is not encryption or DRM**. See `LICENSE.txt`.
