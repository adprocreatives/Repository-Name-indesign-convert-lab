#!/usr/bin/env python3
"""Prepare editable PDF text, verified separate images, and source-vector gradients for InDesign.

Produces a pptx2indesign-compatible (separate pdf2indesign) manifest plus
linked assets, page render references and an extraction report.  The native
InDesign JSX script consumes the manifest; this script does NOT write INDD.

Created By Basheer Parammal | Copyright 2026 adprocreatives.
"""
from __future__ import annotations

import argparse
import copy
import xml.etree.ElementTree as ET
from collections import Counter
import hashlib
import io
import json
import math
from pathlib import Path
import re
import sys
from typing import Any

try:
    import fitz  # PyMuPDF
    from PIL import Image, ImageChops
except ImportError:
    sys.exit('Missing PyMuPDF or Pillow: python3 -m pip install -r requirements.txt')

MAX_PATHS_PER_PAGE = 1500
MAX_PATH_POINTS_PER_PAGE = 15000
MAX_PAGE_SIDE = 18000.0
COLOR_NONE = {'color': None, 'opacity': 100}
STROKE_NONE = {'color': None, 'width': 0}


def c_rgb(rgb: Any) -> str | None:
    if rgb is None:
        return None
    try:
        values = [max(0, min(255, round(float(v) * 255))) for v in list(rgb)[:3]]
        if len(values) == 3:
            return ''.join('%02X' % v for v in values)
    except (ValueError, TypeError):
        pass
    return None


def int_rgb(rgb: Any) -> str:
    try:
        return '%06X' % (int(rgb) & 0xFFFFFF)
    except (TypeError, ValueError):
        return '000000'


def num(value: Any) -> float:
    return round(float(value), 3)


def pt(v: Any) -> list[float]:
    return [num(v.x), num(v.y)]


def rect_dims(rect: Any) -> dict[str, float]:
    return {'x': num(rect.x0), 'y': num(rect.y0),
            'w': num(max(.1, rect.width)), 'h': num(max(.1, rect.height))}


def close_points(a: list[float], b: list[float], eps: float = 0.4) -> bool:
    return abs(a[0] - b[0]) < eps and abs(a[1] - b[1]) < eps


def drawing_style(d: dict) -> tuple[dict, dict]:
    fill = {'color': c_rgb(d.get('fill')), 'opacity': round(100 * (d.get('fill_opacity') or 0), 1)}
    width = d.get('width') or 0
    stroke = {'color': c_rgb(d.get('color')), 'width': num(max(0, min(50, width)))}
    if not stroke['color'] or stroke['width'] <= 0:
        stroke = dict(STROKE_NONE)
    return fill, stroke


def pdf_drawing_parts(d: dict, idx: int, counts: Counter) -> list[dict]:
    """Convert rects, lines and cubic Béziers into editable element descriptors.

    The path style and subpath data are retained; clipping masks, compound fill
    rules and complex PDF transparency are not represented.
    """
    fill, stroke = drawing_style(d)
    if not fill['color'] and not stroke['color']:
        return []
    elements: list[dict] = []
    items = d.get('items', [])
    if len(items) == 1 and items[0][0] == 're':
        r = items[0][1]
        if r.width > .06 and r.height > .06:
            elements.append({'kind': 'rect', 'name': f'PDF vector rectangle {idx}',
                             'rounded': False, 'rotation': 0, 'fill': fill, 'stroke': stroke,
                             **rect_dims(r)})
            counts['rectangles'] += 1
        return elements

    contours: list[list] = []
    points: list = []
    anchor: list | None = None

    def start_point(coord: list):
        nonlocal anchor, points
        if points:
            contours.append(points)
        points = [coord]
        anchor = coord

    def add_linear(begin: list, end: list):
        nonlocal points, anchor
        if not points or anchor is None or not close_points(anchor, begin):
            start_point(begin)
        if not close_points(anchor, end):
            points.append(end)
        anchor = end

    def add_bezier(begin: list, c1: list, c2: list, end: list):
        nonlocal anchor, points
        if not points or anchor is None or not close_points(anchor, begin):
            start_point(begin)
        previous = points[-1]
        if len(previous) == 2:
            prev_anchor = previous
            points[-1] = [list(prev_anchor), list(prev_anchor), c1]
        else:
            points[-1][2] = c1
        points.append([c2, end, end])
        anchor = end

    for item in items:
        op = item[0]
        try:
            if op == 're':
                r = item[1]
                if r.width > .06 and r.height > .06:
                    if points:
                        contours.append(points)
                        points = []
                    contours.append([pt(r.tl), pt(r.tr), pt(r.br), pt(r.bl)])
                    anchor = None
            elif op == 'qu':
                q = item[1]
                if points:
                    contours.append(points)
                    points = []
                contours.append([pt(q.ul), pt(q.ur), pt(q.lr), pt(q.ll)])
                anchor = None
            elif op == 'l':
                add_linear(pt(item[1]), pt(item[2]))
            elif op == 'c':
                add_bezier(pt(item[1]), pt(item[2]), pt(item[3]), pt(item[4]))
            else:
                counts['unsupported_path_commands'] += 1
        except (TypeError, AttributeError, ValueError, IndexError):
            counts['skipped_path_commands'] += 1
    if points:
        contours.append(points)
    filled = bool(fill.get('color'))
    for part, contour in enumerate(contours):
        if len(contour) < 2:
            continue
        if len(contour) > 1200:
            counts['path_too_complex'] += 1
            continue
        first = contour[0][1] if len(contour[0]) == 3 else contour[0]
        last = contour[-1][1] if len(contour[-1]) == 3 else contour[-1]
        closed = bool(filled or d.get('closePath') or close_points(first, last))
        if closed and len(contour) > 2 and close_points(first, last):
            # Last point repeats the first. Preserve its incoming left handle.
            if len(contour[-1]) == 3 and len(contour[0]) == 3:
                contour[0][0] = contour[-1][0]
            contour.pop()
        if len(contour) < 2:
            continue
        elements.append({'kind': 'path', 'name': f'PDF vector path {idx}.{part+1}',
                         'closed': closed, 'points': contour,
                         'stroke': stroke, 'fill': fill if filled and closed else dict(COLOR_NONE),
                         'rotation': 0})
        counts['paths'] += 1
        counts['path_points'] += len(contour)
    return elements


def export_reference(page: Any, idx: int, out: Path, max_pixels: int = 2200) -> str:
    """A page screenshot goes on a hidden, non-printing visual-reference layer."""
    refdir = out / 'reference'
    refdir.mkdir(exist_ok=True)
    scale = min(1.6, max_pixels / max(page.rect.width, page.rect.height))
    scale = max(.2, scale)
    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
    img = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
    target = refdir / ('page_%03d.jpg' % idx)
    img.save(target, 'JPEG', quality=81, optimize=True)
    return 'reference/' + target.name


def save_image_bytes(data: bytes, ext: str, folder: Path, counts: Counter) -> str:
    """Normalize images to PNG/JPG readable by InDesign; deduplicate assets."""
    digest = hashlib.sha256(data).hexdigest()[:24]
    ext = (ext or 'png').lower()
    if ext == 'jpeg':
        ext = 'jpg'
    if ext not in ('jpg', 'png'):
        ext = 'png'
    filename = digest + '.' + ext
    target = folder / filename
    if not target.exists():
        try:
            with Image.open(io.BytesIO(data)) as img:
                if ext == 'jpg' and img.mode in ('RGB', 'L'):
                    target.write_bytes(data)
                else:
                    if img.mode not in ('RGBA', 'RGB'):
                        img = img.convert('RGBA' if ('A' in img.getbands() or 'transparency' in img.info) else 'RGB')
                    filename = digest + '.png'
                    target = folder / filename
                    img.save(target, 'PNG')
            counts['unique_assets'] += 1
        except Exception:
            counts['bad_images'] += 1
            return ''
    return 'assets/' + filename



# v3.3: layout-aware paragraphs and individually placed, clipped PDF images.
# v3.2: layout-aware paragraph reconstruction across PDF text block boundaries.
# Placed PDF artwork retains native transparency, gradients and complex masks.
from urllib.parse import quote_plus
from urllib.request import Request, urlopen


def clean_font_name(raw: str) -> str:
    raw = re.sub(r'^[A-Za-z]{6}\+', '', raw or '')
    return raw.replace('#20', ' ').strip()


def readable_family(ps_name: str) -> str:
    """Only a search hint: preserve exact PostScript font name in the manifest."""
    family = clean_font_name(ps_name).split('-')[0].replace('_', ' ')
    family = re.sub(r'(?:PSMT|MT)$', '', family)
    family = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', family)
    return family.strip() or ps_name


def _span_font(span: dict, fonts: dict) -> dict:
    ps_name = clean_font_name(str(span.get('font') or ''))
    font_size = max(1.0, float(span.get('size') or 11))
    flags = int(span.get('flags') or 0)
    lower = ps_name.lower()
    if ps_name:
        fonts[ps_name] = fonts.get(ps_name, 0) + len(str(span.get('text', '')))
    return {
        'name': ps_name or None,
        'postscript': ps_name or None,
        'familyHint': readable_family(ps_name),
        'size': num(font_size),
        'bold': bool(flags & 16) or any(p in lower for p in ('bold', 'black', 'heavy', 'demi', '-bd')),
        'italic': bool(flags & 2) or any(p in lower for p in ('italic', 'oblique')),
        'serif': bool(flags & 4),
        'mono': bool(flags & 8),
        'color': int_rgb(span.get('color')),
    }


def _line_from_pdf(src_line: dict, block_id: int, counts: Counter, fonts: dict) -> dict | None:
    parts = []
    boxes = []
    for span in src_line.get('spans', []):
        value = str(span.get('text', '')).replace('\x00', '')
        if not value.strip():
            continue
        box = fitz.Rect(span.get('bbox', (0, 0, 0, 0)))
        if box.is_empty or not all(math.isfinite(v) for v in box):
            continue
        parts.append({'text': value, 'box': box, 'font': _span_font(span, fonts)})
        boxes.append(box)
        counts['pdf_text_spans'] += 1
    if not parts:
        return None
    box = fitz.Rect(boxes[0])
    for b in boxes[1:]: box |= b
    direction = src_line.get('dir', (1, 0))
    is_rotated = abs(float(direction[1])) > 0.065 or float(direction[0]) < .97
    if is_rotated: counts['rotated_text_lines'] += 1
    main_font = max(parts, key=lambda p: len(p['text'].strip()))['font']
    return {
        'bbox': box,
        'parts': parts,
        'content': ''.join(p['text'] for p in parts).strip(),
        'size': main_font['size'],
        'main_font': main_font,
        'block_id': block_id,
        'rotated': is_rotated,
    }


def _similar_text_line(a: dict, b: dict) -> bool:
    if a['rotated'] or b['rotated']: return False
    if abs(a['size'] - b['size']) > max(1.1, min(a['size'], b['size']) * .16):
        return False
    fa, fb = a['main_font'], b['main_font']
    # Keep actual headings/bold labels separate. Mixed runs within a line are retained.
    if fa['postscript'] != fb['postscript'] and (fa['bold'] != fb['bold'] or fa['italic'] != fb['italic']):
        return False
    a0, b0 = a['bbox'], b['bbox']
    size = max(a['size'], b['size'])
    delta_y = b0.y0 - a0.y0
    if delta_y < size * .73 or delta_y > size * 1.83:
        return False
    # A line in a neighboring column must not attach to a different column.
    horizontal_overlap = min(a0.x1, b0.x1) - max(a0.x0, b0.x0)
    if horizontal_overlap < min(a0.width, b0.width) * .28:
        return False
    if abs(b0.x0 - a0.x0) > max(25, size * 2.15):
        return False
    if re.match(r'^\s*(?:[\u2022\u25cf\u25e6]|\d{1,2}[.)])\s+', b['content']):
        return False
    # A visibly shorter sentence ending in a period suggests a new paragraph,
    # but don't split a justified column merely due to a wrapped sentence.
    if a['content'].rstrip().endswith(('.', '!', '?', ':')) and len(a['content']) < 30 and b['block_id'] != a['block_id']:
        return False
    return True


def collect_pdf_paragraphs(page: Any, counts: Counter, fonts: dict) -> list[list[dict]]:
    """Build vertical text chains across blocks, never joining columns by y alone."""
    data = page.get_text('dict', flags=fitz.TEXTFLAGS_TEXT)
    lines: list[dict] = []
    for block_idx, block in enumerate(data.get('blocks', [])):
        if block.get('type') != 0: continue
        for line in block.get('lines', []):
            value = _line_from_pdf(line, block_idx, counts, fonts)
            if value: lines.append(value)
    counts['source_pdf_text_lines'] += len(lines)
    lines.sort(key=lambda line: (round(line['bbox'].y0, 2), line['bbox'].x0))
    chains: list[list[dict]] = []
    for line in lines:
        best_idx, best_score = -1, 1e9
        for idx in range(len(chains) - 1, -1, -1):
            last = chains[idx][-1]
            if line['bbox'].y0 - last['bbox'].y0 > line['size'] * 2.25:
                continue
            if not _similar_text_line(last, line):
                continue
            delta_y = (line['bbox'].y0 - last['bbox'].y0) / max(line['size'], 1)
            dx = abs(line['bbox'].x0 - last['bbox'].x0) / max(line['size'], 1)
            # Prefer an immediate predecessor with matching left edge and font.
            score = abs(delta_y - 1.2) * 5 + dx * 1.25 + (0 if last['block_id'] == line['block_id'] else .36)
            if score < best_score:
                best_score, best_idx = score, idx
        if best_idx >= 0:
            if chains[best_idx][-1]['block_id'] != line['block_id']:
                counts['pdf_cross_block_joins'] += 1
            chains[best_idx].append(line)
        else:
            chains.append([line])
    chains.sort(key=lambda group: (group[0]['bbox'].y0, group[0]['bbox'].x0))
    return chains


def _collapse_run_list(runs: list[dict]) -> list[dict]:
    merged = []
    for run in runs:
        if not run['length']: continue
        if merged and merged[-1]['font'] == run['font'] and merged[-1]['start'] + merged[-1]['length'] == run['start']:
            merged[-1]['length'] += run['length']
        else:
            merged.append(run)
    return merged


def _text_frame_from_lines(lines: list[dict], page_width: float, counts: Counter) -> dict:
    left = min(line['bbox'].x0 for line in lines)
    top = min(line['bbox'].y0 for line in lines)
    right = max(line['bbox'].x1 for line in lines)
    bottom = max(line['bbox'].y1 for line in lines)
    font_size = max(line['size'] for line in lines)
    text = ''
    runs = []
    for index, line in enumerate(lines):
        if index:
            # PDF line wraps become spaces inside one editable paragraph.
            text += ' '
        parts = line['parts']
        for pos, part in enumerate(parts):
            chunk = part['text'].lstrip() if pos == 0 else part['text']
            chunk = chunk.rstrip() if pos == len(parts)-1 else chunk
            if not chunk: continue
            if pos and text and not text[-1].isspace() and not chunk[0].isspace():
                previous = parts[pos - 1]
                gap = part['box'].x0 - previous['box'].x1
                if gap > max(1.0, part['font']['size'] * .17):
                    text += ' '
            begin = len(text)
            text += chunk
            runs.append({'start': begin, 'length': len(chunk), 'font': part['font']})
    text = text.strip()
    main_font = lines[0]['main_font']
    box_width = max(1, right-left)
    # Provide measured metrics plus a small tolerance for font-engine variation.
    width = min(page_width-left, box_width + max(5, font_size * .48))
    height = max(bottom-top + font_size*.8, len(lines)*font_size*1.43)
    centers = [(line['bbox'].x0+line['bbox'].x1)/2 for line in lines]
    alignment = 'left'
    if len(lines)>1 and max(centers)-min(centers) < box_width*.06 and max(l['bbox'].x0 for l in lines)-left > font_size*.5:
        alignment = 'center'
    counts['text_frames'] += 1
    counts['editable_paragraphs'] += 1
    if len(lines)>1:
        counts['paragraphs_with_wrapped_lines'] += 1
        counts['wrapped_lines_joined'] += len(lines)-1
    return {
        'kind': 'text',
        'name': f'PDF paragraph ({len(lines)} source lines)',
        'x': num(left), 'y': num(top),
        'w': num(max(.2,width)), 'h': num(height), 'rotation': 0,
        'text': {'text': text, 'insets': [0,0,0,0], 'anchor': 'top',
                 'paragraphs': [{'alignment': alignment, 'font': main_font, 'runs': _collapse_run_list(runs)}]},
    }


def _pdf_text_elements(page: Any, counts: Counter, fonts: dict) -> list[dict]:
    groups = collect_pdf_paragraphs(page, counts, fonts)
    return [_text_frame_from_lines(group, page.rect.width, counts) for group in groups]


def _online_font_lookup(names: dict, output_dir: Path, enabled: bool) -> None:
    """Check publicly accessible Google Fonts without downloading unlicensed fonts.

    Only family names are sent; no text, designs or PDF bytes leave the machine.
    Adobe Fonts requires a licensed Creative Cloud user to activate fonts.
    """
    results = []
    families = []
    seen = set()
    for ps_name in sorted(names, key=lambda n: -names[n]):
        hint = readable_family(ps_name)
        if hint.lower() not in seen:
            families.append(hint)
            seen.add(hint.lower())
    results.extend([
        'Font availability report (source names are PDF PostScript names)',
        'Only font family names are queried online; the original PDF is not uploaded.',
        'No fonts are installed, embedded, copied or distributed by this tool.',
        '',
    ])
    offline = False
    for index, family in enumerate(families):
        ps_list = [p for p in names if readable_family(p) == family]
        ps = ', '.join(ps_list)
        google = 'https://fonts.google.com/?query=' + quote_plus(family)
        adobe = 'https://fonts.adobe.com/search?query=' + quote_plus(family)
        status = 'Not checked'
        if enabled and index < 16 and not offline:
            try:
                url = 'https://fonts.googleapis.com/css2?family=' + quote_plus(family) + '&display=swap'
                request = Request(url, headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X) AppleWebKit/537.36 Chrome/124 Safari/537.36'})
                with urlopen(request, timeout=2.75) as response:
                    value = response.read(4000)
                    status = 'Available at Google Fonts' if response.status == 200 and b'@font-face' in value else 'Not found at Google Fonts'
            except Exception:
                status = 'Not confirmed online (offline, blocked or unavailable)'
                offline = True
        elif enabled:
            status = 'Not checked (offline or lookup limit reached)'
        results.extend([family + '  [PostScript: ' + ps + ']', '  ' + status,
                        '  Google Fonts: ' + google, '  Adobe Fonts: ' + adobe, ''])
    (output_dir/'font_lookup.txt').write_text('\n'.join(results)+'\n', encoding='utf-8')


# The original PDF's vector content stays in a linked PDF after removing the
# actual image XObjects. Each visible image is exported on its own, with the
# original SVG clip path, soft mask and transforms baked into its alpha pixels.
# Other vector objects remain in the preserved PDF, not flattened to an image.
_SVG_MASK_CACHE = {}
SVG_NS = 'http://www.w3.org/2000/svg'
XLINK_NS = 'http://www.w3.org/1999/xlink'
ET.register_namespace('', SVG_NS)
ET.register_namespace('xlink', XLINK_NS)
ET.register_namespace('inkscape', 'http://www.inkscape.org/namespaces/inkscape')


def _svg_visible_images(page: Any, counts: Counter, warnings: list) -> tuple[list, dict, list]:
    """Return individual image nodes; images inside <defs> are masks, not placements."""
    svg = page.get_svg_image(text_as_path=False)
    if len(svg) > 130_000_000:
        warnings.append('Large SVG page; image isolation may be slow')
    root = ET.fromstring(svg)
    parent = {child: p for p in root.iter() for child in p}
    visible = []
    for node in root.iter():
        if node.tag != '{' + SVG_NS + '}image':
            continue
        p = node
        in_defs = False
        while p in parent:
            p = parent[p]
            if p.tag == '{' + SVG_NS + '}defs':
                in_defs = True
                break
        if not in_defs:
            visible.append(node)
    counts['svg_visible_images'] += len(visible)
    definitions = [node for node in root if node.tag == '{' + SVG_NS + '}defs']
    return visible, parent, [root, definitions]


def _isolated_svg(root: Any, definitions: list, parent: dict, target: Any) -> bytes:
    """Keep only image and ancestors, retaining its PDF-defined SVG masks/clips.

    Using the literal 'xlink' namespace prefix matters for MuPDF SVG rendering.
    """
    new_root = ET.Element(root.tag, dict(root.attrib))
    for defs in definitions:
        new_root.append(copy.deepcopy(defs))
    lineage = []
    node = target
    while node in parent:
        lineage.append(node)
        node = parent[node]
    ancestor = new_root
    for node in reversed(lineage):
        if node is target:
            ancestor.append(copy.deepcopy(target))
        else:
            ancestor = ET.SubElement(ancestor, node.tag, dict(node.attrib))
    return ET.tostring(new_root, encoding='utf-8')


def _manual_svg_clip_alpha(page: Any, target: Any, parent: dict, root: Any,
                           definitions: list, scale: float, counts: Counter) -> Image.Image | None:
    """Render explicit clipPath definitions as alpha masks.

    MuPDF's SVG rasterizer currently skips certain PDF-generated SVG clip-paths
    on embedded raster images. Rendering each clipping *path* separately and
    multiplying its alpha is more reliable than letting the image ignore it.
    """
    ids = {}
    for definition in definitions:
        for node in definition.iter():
            if node.get('id'):
                ids[node.get('id')] = node
    clip_ids = []
    cursor = target
    while cursor in parent:
        cursor = parent[cursor]
        raw_clip = cursor.get('clip-path', '')
        raw_clip += ' ' + cursor.get('style','')
        for match in re.findall(r'url\(\s*#([A-Za-z0-9_\-]+)\s*\)', raw_clip):
            if match in ids and ids[match].tag == '{' + SVG_NS + '}clipPath' and match not in clip_ids:
                clip_ids.append(match)
    if not clip_ids:
        return None
    alpha = None
    for clip_id in clip_ids:
        clip = ids[clip_id]
        cache_key = (int(page.xref),clip_id,round(scale,2))
        if cache_key in _SVG_MASK_CACHE:
            channel = _SVG_MASK_CACHE[cache_key]
            alpha = channel if alpha is None else ImageChops.multiply(alpha,channel)
            continue
        mask_root = ET.Element(root.tag, dict(root.attrib))
        for definition in definitions:
            mask_root.append(copy.deepcopy(definition))
        container = ET.SubElement(mask_root, '{' + SVG_NS + '}g')
        for child in clip:
            elem = copy.deepcopy(child)
            # PDF clipping geometry only needs its filled path silhouette.
            if elem.get('fill') is None:
                elem.set('fill','#ffffff')
            elem.set('stroke','none')
            container.append(elem)
        clip_bytes = ET.tostring(mask_root, encoding='utf-8')
        try:
            d = fitz.open(stream=clip_bytes,filetype='svg')
            try:
                pix = d[0].get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=True)
            finally:
                d.close()
            channel = Image.frombytes('RGBA', (pix.width,pix.height),pix.samples).getchannel('A')
            if len(_SVG_MASK_CACHE) > 10:
                _SVG_MASK_CACHE.clear()
            _SVG_MASK_CACHE[cache_key] = channel
            if alpha is None:
                alpha = channel
            else:
                alpha = ImageChops.multiply(alpha,channel)
            counts['pdf_clip_masks_preserved'] += 1
        except Exception:
            counts['failed_clip_paths'] += 1
            continue
    return alpha


def _save_isolated_image(page: Any, page_num: int, image_num: int, svg_bytes: bytes,
                         assetdir: Path, counts: Counter, target: Any, parent: dict,
                         root: Any, definitions: list) -> dict | None:
    """Rasterize *one* source image with its mask, crop transparency, save linked asset."""
    svg_doc = fitz.open(stream=svg_bytes, filetype='svg')
    scale = min(2.0, 1800.0 / max(page.rect.width, page.rect.height))
    scale = max(0.65, scale)
    try:
        pix = svg_doc[0].get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=True)
    finally:
        svg_doc.close()
    img = Image.frombytes('RGBA', (pix.width, pix.height), pix.samples)
    manual_clip = _manual_svg_clip_alpha(page,target,parent,root,definitions,scale,counts)
    if manual_clip is not None and manual_clip.size == img.size:
        img.putalpha(ImageChops.multiply(img.getchannel('A'),manual_clip))
    bbox = img.getchannel('A').getbbox()
    if not bbox:
        counts['empty_svg_images'] += 1
        return None
    # Preserve 1-2px edges of antialiased clipping contours.
    x0, y0, x1, y1 = bbox
    x0 = max(0, x0 - 1); y0 = max(0, y0 - 1)
    x1 = min(img.width, x1 + 1); y1 = min(img.height, y1 + 1)
    cropped = img.crop((x0, y0, x1, y1))
    alpha_min, alpha_max = cropped.getchannel('A').getextrema()
    basename = 'pdf_%03d_photo_%03d' % (page_num, image_num)
    if alpha_min == alpha_max == 255:
        # JPEG avoids storing huge flattened (but individually movable) photos
        # as uncompressed RGB while PNG is required for clipped transparency.
        path = assetdir / (basename + '.jpg')
        cropped.convert('RGB').save(path, 'JPEG', quality=96, subsampling=0, optimize=True)
        counts['standalone_jpg_images'] += 1
    else:
        path = assetdir / (basename + '.png')
        cropped.save(path, 'PNG', compress_level=6)
        counts['standalone_masked_png_images'] += 1
    counts['individual_images'] += 1
    return {
        'kind':'image', 'name': 'PDF photo %d (independent linked image)' % image_num,
        'path':'assets/' + path.name, 'rotation':0,
        'x':num(x0/scale), 'y':num(y0/scale),
        'w':num((x1-x0)/scale), 'h':num((y1-y0)/scale),
        'sourceType':'pdf_embedded_image',
        'layerRole':'background' if (x1-x0)*(y1-y0) / max(1, img.width*img.height) > .42 else 'foreground',
        'masked':alpha_min != 255, 'sourcePage':page_num,
    }


def _rect_similarity(box_a: Any, box_b: Any) -> float:
    """Match SVG image alpha extents to PDF image XObject bounds."""
    a = fitz.Rect(box_a); b = fitz.Rect(box_b)
    intersect = a & b
    if intersect.is_empty or a.is_empty or b.is_empty:
        return 0.0
    area = intersect.width * intersect.height
    return area / max(.01, min(a.width*a.height, b.width*b.height))


def _embed_pdf_soft_mask(svg_bytes: bytes, pdf: Any, image_xref: int,
                         mask_xref: int, counts: Counter) -> bytes:
    """Bake PDF /SMask into only the corresponding SVG image, not the whole page.

    MuPDF's own SVG rasterizer sometimes ignores <mask> luminance, leaving
    large opaque black rectangles around transparent logos. The exact source
    XObject soft mask is more reliable than recreating it with SVG renderers.
    """
    try:
        color = pdf.extract_image(image_xref)
        mask = pdf.extract_image(mask_xref)
        with Image.open(io.BytesIO(color['image'])) as raw:
            rgba = raw.convert('RGBA')
        with Image.open(io.BytesIO(mask['image'])) as srcmask:
            alpha = srcmask.convert('L')
        if alpha.size != rgba.size:
            alpha = alpha.resize(rgba.size, Image.Resampling.BICUBIC)
        rgba.putalpha(ImageChops.multiply(rgba.getchannel('A'),alpha))
        buffer=io.BytesIO();rgba.save(buffer,format='PNG')
        import base64
        uri='data:image/png;base64,'+base64.b64encode(buffer.getvalue()).decode('ascii')
        isolated=ET.fromstring(svg_bytes)
        target_size=(str(color['width']),str(color['height']))
        found=False
        parents={c:p for p in isolated.iter() for c in p}
        for node in isolated.iter():
            if node.tag != '{%s}image' % SVG_NS or (node.get('width'),node.get('height'))!=target_size:
                continue
            cursor=node; in_def=False
            while cursor in parents:
                cursor=parents[cursor]
                if cursor.tag == '{%s}defs' % SVG_NS:
                    in_def=True;break
            if in_def:continue
            node.set('{%s}href' % XLINK_NS,uri)
            found=True
            break
        if not found:return svg_bytes
        for node in isolated.iter():
            if node.tag == '{%s}g' % SVG_NS and node.get('mask','').startswith('url('):
                node.attrib.pop('mask')
        counts['source_soft_masks_repaired'] += 1
        return ET.tostring(isolated,encoding='utf-8')
    except Exception:
        counts['source_soft_mask_repair_failed'] += 1
        return svg_bytes


def _image_digest(png_or_jpg: bytes) -> tuple[tuple[int, int], str]:
    """Compare *decoded pixels*; PDF XObject names and bounds are not reliable IDs.

    In particular, rasterized SVG shadings must never be confused with photos.
    """
    with Image.open(io.BytesIO(png_or_jpg)) as img:
        rgba = img.convert('RGBA')
        return rgba.size, hashlib.sha256(rgba.tobytes()).hexdigest()


def _image_is_flat_shape(raw: bytes, width: int, height: int) -> bool:
    """Leave bitmap shapes / gradient mask XObjects in the vector PDF background.

    This is conservative: photos, logos and product graphics are still extracted;
    large nearly-uniform, white-masked decorative shapes remain in original PDF.
    """
    if width < 130 or height < 120:
        return False
    with Image.open(io.BytesIO(raw)) as img:
        sm = img.convert('RGB')
        sm.thumbnail((96, 96))
        grey = sm.convert('L')
        histogram = grey.histogram()
        total = max(1, sum(histogram))
        entropy = -sum((h / total) * math.log2(h / total)
                       for h in histogram if h)
        from PIL import ImageFilter, ImageStat
        edge = ImageStat.Stat(grey.filter(ImageFilter.FIND_EDGES)).mean[0]
        return entropy < 1.55 and edge >= 6.4


def extract_pdf_individual_images(page: Any, page_num: int, assetdir: Path,
                                  counts: Counter, warnings: list) -> tuple[list[dict], set[str]]:
    """Export only actual source XObjects, exactly matched by their pixel digests.

    Avoid arbitrary positional matching: PDF shadings are frequently rasterized
    as SVG <image> nodes, even though they are native vector gradients in the PDF.
    This was the cause of missing and distorted backgrounds in v3.3.
    """
    pdf = page.parent
    source_images = {}
    for record in page.get_images(full=True):
        xref = int(record[0])
        if xref in source_images or xref <= 0:
            continue
        try:
            im = pdf.extract_image(xref)
            if not im or im.get('width', 0) < 35 or im.get('height', 0) < 35:
                counts['tiny_pictures_kept_in_background'] += 1
                continue
            if _image_is_flat_shape(im['image'], im['width'], im['height']):
                counts['decorative_raster_shapes_preserved_in_background'] += 1
                continue
            dimensions, digest = _image_digest(im['image'])
            source_images[xref] = {'dimensions':dimensions,'digest':digest,
                                   'raw':im['image'],'smask':int(record[1] or 0)}
        except Exception as exc:
            warnings.append('Page %d: XObject %d could not be inspected: %s' % (page_num,xref,exc))
    if not source_images:
        return [],set()
    try:
        visible, parent, wrapper = _svg_visible_images(page,counts,warnings)
    except Exception as exc:
        warnings.append('Page %d: image isolation failed; all images preserved: %s' % (page_num,exc))
        return [],set()
    root, defs = wrapper
    if len(visible)>120:
        warnings.append('Page %d: too many image operators; keeping all in background' % page_num)
        return [],set()

    # The PDF image operators are the truth for counts. SVG can also emit
    # synthetic raster tiles for mesh shades -- these are NOT extractable photos.
    image_info = page.get_image_info(xrefs=True)
    occurrences = Counter(int(v.get('xref',0)) for v in image_info if int(v.get('xref',0))>0)
    matches = {xref:[] for xref in source_images}
    for candidate in visible:
        href = candidate.get('{%s}href' % XLINK_NS) or candidate.get('href','')
        if 'base64,' not in href:
            continue
        try:
            candidate_size, candidate_digest = _image_digest(__import__('base64').b64decode(href.split('base64,')[-1]))
        except Exception:
            continue
        for xref, meta in source_images.items():
            if candidate_size == meta['dimensions'] and candidate_digest == meta['digest']:
                matches[xref].append(candidate)
                break
    exported = []
    removable = set()
    for xref, nodes in matches.items():
        needs = max(1,occurrences[xref])
        if len(nodes) < needs:
            counts['unmatched_source_images_preserved'] += 1
            warnings.append('Page %d: image XObject %d matched %d/%d placements; kept in original PDF' %
                            (page_num,xref,len(nodes),needs))
            continue
        assets_for_xref = []
        try:
            for node in nodes:
                serial = len(exported) + len(assets_for_xref) + 1
                svg_bytes = _isolated_svg(root,defs,parent,node)
                if source_images[xref]['smask'] > 0:
                    svg_bytes = _embed_pdf_soft_mask(svg_bytes,pdf,xref,source_images[xref]['smask'],counts)
                item = _save_isolated_image(page,page_num,serial,svg_bytes,assetdir,counts,node,parent,root,defs)
                if not item:
                    raise ValueError('empty/transparent image placement')
                item['sourceXref'] = xref
                item['name'] = 'PDF photo/graphic XObject %d (editable image)' % xref
                # Original page area, not alpha fraction within the cropped PNG.
                area = item['w']*item['h'] / max(1., page.rect.width*page.rect.height)
                item['layerRole'] = 'background' if area > .35 else 'foreground'
                assets_for_xref.append(item)
        except Exception as exc:
            counts['failed_isolations_kept_in_original_pdf'] += 1
            warnings.append('Page %d: image XObject %d not removed: %s' % (page_num,xref,exc))
            for item in assets_for_xref:
                (assetdir / Path(item['path']).name).unlink(missing_ok=True)
            continue
        # Large image XObjects often sit inside transparency/blend groups
        # with vector shading. Pulling them out changes the gradient's
        # appearance, even if the bitmap was isolated correctly.
        # Retain these in the ORIGINAL VECTOR PDF to guarantee fidelity;
        # separate normal-sized photos and product images as editable links.
        if any(a.get('layerRole')=='background' for a in assets_for_xref):
            for item in assets_for_xref:
                (assetdir / Path(item['path']).name).unlink(missing_ok=True)
            counts['complex_blended_backgrounds_preserved'] += 1
            warnings.append('Page %d: large blended source image %d kept in linked vector background to preserve original transparency' % (page_num,xref))
            continue
        exported.extend(assets_for_xref)
        counts['verified_linked_image_instances'] += len(assets_for_xref)
        removable.add(source_images[xref]['digest'])
        counts['verified_extracted_source_xobjects'] += 1
    return exported, removable


def _make_page_vector_background(source: Any, source_page_index: int, target: Path,
                                 image_digests: set[str], counts: Counter,
                                 warnings: list) -> tuple[bool, set[str]]:
    """Never delete a source/shared xref: COPY ONE PAGE and edit only its copy.

    A copied PDF retains original axial/radial/mesh shading objects (type 2/3/4/7)
    plus native clipping and transparency. Illustrator can open the linked PDF
    and save it as .AI; EPS would destroy native transparency, so is not used.
    """
    one = fitz.open()
    removed = set()
    try:
        one.insert_pdf(source, from_page=source_page_index,
                       to_page=source_page_index, links=False, annots=False)
        page = one[0]
        for record in page.get_images(full=True):
            xref = int(record[0])
            if xref < 1:
                continue
            try:
                raw = one.extract_image(xref)
                if not raw:continue
                _, digest = _image_digest(raw['image'])
                if digest in image_digests and digest not in removed:
                    page.delete_image(xref)
                    removed.add(digest)
                    counts['page_local_photo_xobjects_removed'] += 1
            except Exception as exc:
                warnings.append('Page %d: could not remove cloned photo %d: %s' % (source_page_index+1,xref,exc))
        # Remove selectable text WITHOUT deleting its images or path drawings.
        if page.get_text('text').strip():
            page.add_redact_annot(page.rect, fill=False, cross_out=False)
            page.apply_redactions(images=0, graphics=0, text=0)
        if page.get_text('text').strip():
            warnings.append('Page %d: text not fully removed from vector backdrop' % (source_page_index+1))
        one.save(str(target), garbage=3, deflate=True)
        return True, removed
    except Exception as exc:
        warnings.append('Page %d: could not build vector PDF: %s' % (source_page_index+1,exc))
        return False, removed
    finally:
        one.close()


def _write_vector_notes(out: Path, page_infos: list[dict]):
    lines = [
      'Vector gradient and Illustrator-editing guide (v3.4)',
      'Created By Basheer Parammal | Copyright 2026 adprocreatives.',
      '',
      'The files in vector_assets are real vector PDFs, NOT flattened PNG backgrounds.',
      'The original PDF uses native PDF ShadingType 2 (linear), 3 (radial),',
      '4 (mesh triangles) and 7 (Coons patches) on different pages.',
      'InDesign does not provide native editable equivalents for arbitrary PDF mesh gradients.',
      'Open the linked PDF in Illustrator, edit it and Save As an .AI file.',
      'In InDesign: Links panel > Relink to the newly saved .AI file.',
      'Avoid EPS for artwork involving transparency; EPS can alter flatten/blending.',
      'If a gradient is already stored as bitmap pixels in the PDF, linked PDF cannot make it editable.',
      'Only original artwork/source Illustrator files preserve those objects faithfully.',
      '', 'PAGE-BY-PAGE',
    ]
    for item in page_infos:
        lines.append('Page %02d: %s, individually movable images: %d' %
                     (item['page'],', '.join('Type %s: %d' % (k,v) for k,v in sorted(item['shading'].items())) or 'No detected shadings',item['images']))
    (out/'VECTOR_EDITING_README.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def _page_shading_types(document: Any, page: Any) -> Counter:
    """Diagnose shading types in page and nested form PDF resources."""
    types = Counter()
    seen=set()
    records=[page.xref]+[r[0] for r in page.get_xobjects()]
    for xref in records:
        try:
            desc=document.xref_object(xref)
            for ref in re.findall(r'/Sh\d+\s+(\d+)\s+0\s+R',desc):
                if ref in seen:continue
                seen.add(ref)
                detail=document.xref_object(int(ref))
                match=re.search(r'/ShadingType\s+(\d+)',detail)
                if match:types[match.group(1)]+=1
        except Exception:pass
    return types

def run(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description='Prepare PDF for fidelity-first InDesign recreation')
    parser.add_argument('pdf', help='PDF file')
    parser.add_argument('--out')
    parser.add_argument('--mode', choices=['hybrid','native'], default='hybrid',
                        help='hybrid preserves artwork as placed vector PDF with editable text')
    parser.add_argument('--online-fonts', action='store_true', help='Check public Google Fonts CSS API')
    parser.add_argument('--no-reference', action='store_true')
    args = parser.parse_args(argv)
    infile = Path(args.pdf).expanduser().resolve()
    if not infile.is_file() or infile.suffix.lower() != '.pdf': parser.error('Select an existing PDF')
    outfile = Path(args.out).expanduser().resolve() if args.out else infile.with_name(infile.stem + '_InDesign_Ready')
    outfile.mkdir(parents=True, exist_ok=True)
    assetdir = outfile/'assets';assetdir.mkdir(exist_ok=True)
    counts = Counter(); fonts = {}; warnings=[]; page_infos=[]
    vector_dir = outfile/'vector_assets';vector_dir.mkdir(exist_ok=True)
    document = fitz.open(str(infile))
    if document.needs_pass: parser.error('Encrypted PDFs are not supported')
    if not document.page_count: parser.error('PDF has no pages')
    manifest = {
        'format': 'pdf2indesign-v4',
        'source': infile.name,
        'pageWidth': num(document[0].rect.width),
        'pageHeight': num(document[0].rect.height),
        'pdfMode': args.mode,
        'slides': [],
    }
    for i,page in enumerate(document,1):
        if page.rect.width > MAX_PAGE_SIDE or page.rect.height > MAX_PAGE_SIDE:
            parser.error(f'Page {i} exceeds supported dimensions')
        if page.rotation: warnings.append(f'Page {i}: /Rotate={page.rotation} needs visual review')
        elements = []
        if args.mode == 'native':
            for idx,drawing in enumerate(page.get_drawings()[:MAX_PATHS_PER_PAGE],1):
                elements.extend(pdf_drawing_parts(drawing,idx,counts))
            # Legacy native reconstruction deliberately remains available.
            data = page.get_text('dict', flags=fitz.TEXTFLAGS_DICT)
            for block in data.get('blocks',[]):
                if block.get('type') == 1 and block.get('image'):
                    relpath = save_image_bytes(block['image'], block.get('ext','png'), assetdir, counts)
                    if relpath:
                        elements.append({'kind':'image','name':'PDF image','path':relpath,'rotation':0,**rect_dims(fitz.Rect(block['bbox']))})
        # Source images are sampled BEFORE artwork-PDF image removal.
        if args.mode == 'hybrid':
            independent_images, verified_digests = extract_pdf_individual_images(page,i,assetdir,counts,warnings)
            elements.extend(independent_images)
            vector_pdf = vector_dir/('page_%03d_vector.pdf' % i)
            ok, actually_removed = _make_page_vector_background(document,i-1,vector_pdf,verified_digests,counts,warnings)
            if not ok:
                parser.error('Page %d background preservation failed; refusing incomplete conversion' % i)
            if actually_removed != verified_digests:
                warnings.append('Page %d: not all verified image XObjects removed; avoiding duplicate movable photos for those XObjects' % i)
                elements = [e for e in elements if e.get('kind')!='image' or
                            e.get('sourceXref') is None or
                            _image_digest(document.extract_image(e['sourceXref'])['image'])[1] in actually_removed]
            page_infos.append({'page':i,'shading':_page_shading_types(document,page),'images':len([e for e in elements if e['kind']=='image'])})
        elements.extend(_pdf_text_elements(page,counts,fonts))
        slide = {'number':i, 'width':num(page.rect.width), 'height':num(page.rect.height),
                 'elements':elements, 'reference':None}
        if args.mode == 'hybrid':
            slide['backgroundPDF'] = 'vector_assets/page_%03d_vector.pdf' % i
            slide['backgroundPDFPage'] = 1
        if not args.no_reference:
            try:
                slide['reference'] = export_reference(page,i,outfile)
            except Exception as exc:
                warnings.append(f'Page {i} reference image error: {exc}')
        if not any(e['kind']=='text' for e in elements):
            warnings.append(f'Page {i}: no selectable text; scanned text requires OCR')
        manifest['slides'].append(slide)
        counts['pages'] += 1
        counts['elements'] += len(elements)
        print(f'PDF Page {i:03d}/{document.page_count}: {len(elements)} editable elements, {counts["pdf_cross_block_joins"]} joined across PDF blocks')
    if args.mode == 'hybrid':
        _write_vector_notes(outfile,page_infos)
    document.close()
    (outfile/'conversion_manifest.json').write_text(json.dumps(manifest, ensure_ascii=True),encoding='utf-8')
    (outfile/'fonts_used.txt').write_text('PDF PostScript fonts detected:\n'+'\n'.join(f'{name}\t{n} characters' for name,n in sorted(fonts.items()))+'\n',encoding='utf-8')
    _online_font_lookup(fonts,outfile,args.online_fonts)
    report = [
        'PDF-to-InDesign v3.4 Preparation Report',
        'Created By Basheer Parammal | Copyright 2026 adprocreatives.',
        'Source: '+infile.name,
        'PDF Mode: '+args.mode,
        'In hybrid mode, verified source XObject photos are individually movable linked image assets.',
        'Large, complex blended background photographs remain with original PDF gradients for fidelity.',
        'Native PDF vector shadings remain in a separate linked PDF per page, not a PNG.',
        'Source PDF image clip paths and transparency masks are baked into each extracted photo PNG where possible.',
        'InDesign text is editable and grouped into inferred paragraphs across PDF blocks.',
        'Preserved complex vector backgrounds are still linked PDF objects, editable via Illustrator but not direct InDesign paths.',
        'The source PDF is never modified. Each vector_assets/page_XXX_vector.pdf is an independent PDF copy.',
        'Matching exact typography still requires the fonts on your computer; see font_lookup.txt and InDesign_import_report.txt.',
        'Online font lookup only checks public Google Fonts; it does not fetch or install fonts.',
        'Original PDF mesh gradients are not automatically converted into editable native InDesign gradients.',
        'Use vector_assets PDF files in Illustrator to edit supported native vector shadings.',
        '', 'COUNTS',
    ] + [f'{k}: {counts[k]}' for k in sorted(counts)]
    if warnings: report.extend(['','WARNINGS']+warnings)
    (outfile/'conversion_report.txt').write_text('\n'.join(report)+'\n', encoding='utf-8')
    print('BPCONVERTER_PDF_PREPARED='+str(outfile/'conversion_manifest.json'))

if __name__ == '__main__':
    run()
