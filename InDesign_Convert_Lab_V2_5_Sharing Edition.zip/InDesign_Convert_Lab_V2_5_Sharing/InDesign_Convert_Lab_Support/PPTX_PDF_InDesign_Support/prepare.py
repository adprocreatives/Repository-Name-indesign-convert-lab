#!/usr/bin/env python3
"""Shared dispatch for PPTX or PDF conversion (no INDD created in Python)."""
from pathlib import Path
import argparse
import sys

def main():
    p = argparse.ArgumentParser(description='Prepare PDF/PPTX for Adobe InDesign reconstruction')
    p.add_argument('--kind', choices=['pdf', 'pptx'], required=True)
    p.add_argument('source')
    p.add_argument('--out')
    p.add_argument('--online-fonts', action='store_true', help='Check Google Fonts (family names only)')
    args = p.parse_args()
    src = Path(args.source).expanduser().resolve()
    if not src.is_file() or src.suffix.lower() != ('.' + args.kind):
        p.error('Input must be an existing .' + args.kind + ' file')
    # Existing PPTX tool has its own run() argparse implementation.
    sys.argv = [sys.argv[0], str(src)] + (['--out', args.out] if args.out else []) + (['--online-fonts'] if args.online_fonts and args.kind == 'pdf' else [])
    if args.kind == 'pptx':
        import prepare_pptx
        prepare_pptx.run()
    else:
        import prepare_pdf
        prepare_pdf.run()

if __name__ == '__main__':
    main()
