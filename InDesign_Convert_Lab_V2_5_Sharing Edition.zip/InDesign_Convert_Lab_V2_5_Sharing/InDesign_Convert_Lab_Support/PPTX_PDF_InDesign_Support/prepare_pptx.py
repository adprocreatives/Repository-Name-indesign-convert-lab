#!/usr/bin/env python3
"""Prepare an editable PowerPoint-to-InDesign import package.

Run: python3 prepare_pptx.py presentation.pptx --out output_folder
Optionally: --references folder_with_exported_slide_jpgs

The resulting manifest is consumed by InDesign_Import_PPTX.jsx in InDesign.
This stage does NOT create an INDD/IDML; only InDesign itself does that.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import shutil
import sys
from collections import Counter
from pathlib import Path
from typing import Any
from zipfile import ZipFile
from xml.etree import ElementTree as ET

try:
    from pptx import Presentation
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    from pptx.enum.dml import MSO_COLOR_TYPE, MSO_FILL
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    from PIL import Image
except ImportError:
    sys.exit('Missing packages. Run: python3 -m pip install -r requirements.txt')

EMU_PER_POINT = 12700.0
NS = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'}
THEME_KEYS = {
    'DARK_1': 'dk1', 'LIGHT_1': 'lt1', 'DARK_2': 'dk2', 'LIGHT_2': 'lt2',
    'ACCENT_1': 'accent1', 'ACCENT_2': 'accent2', 'ACCENT_3': 'accent3',
    'ACCENT_4': 'accent4', 'ACCENT_5': 'accent5', 'ACCENT_6': 'accent6',
    'HYPERLINK': 'hlink', 'FOLLOWED_HYPERLINK': 'folHlink',
}
FALLBACK_THEME = {
    'dk1': '000000', 'lt1': 'FFFFFF', 'dk2': '1F497D', 'lt2': 'EEECE1',
    'accent1': '4472C4', 'accent2': 'ED7D31', 'accent3': 'A5A5A5',
    'accent4': 'FFC000', 'accent5': '5B9BD5', 'accent6': '70AD47',
}


def pts(emu: Any) -> float:
    if emu is None:
        return 0.0
    return round(float(emu) / EMU_PER_POINT, 4)


def load_theme(path: Path) -> dict[str, str]:
    colors = dict(FALLBACK_THEME)
    with ZipFile(path) as zf:
        names = [x for x in zf.namelist() if re.match(r'ppt/theme/theme\d+\.xml$', x)]
        if not names:
            return colors
        root = ET.fromstring(zf.read(sorted(names)[0]))
        scheme = root.find('.//a:clrScheme', NS)
        if scheme is None:
            return colors
        for node in scheme:
            key = node.tag.rsplit('}', 1)[-1]
            for child in node:
                if child.tag.endswith('srgbClr'):
                    colors[key] = child.get('val', colors.get(key, '000000')).upper()
                    break
                if child.tag.endswith('sysClr'):
                    colors[key] = child.get('lastClr', '000000').upper()
                    break
    return colors


def color_hex(color: Any, theme: dict[str, str]) -> str | None:
    try:
        if color.type == MSO_COLOR_TYPE.RGB and color.rgb is not None:
            return str(color.rgb).upper()
        if color.type == MSO_COLOR_TYPE.SCHEME and color.theme_color is not None:
            key = THEME_KEYS.get(str(color.theme_color).split(' ')[0], 'dk1')
            return theme.get(key, '000000')
    except (AttributeError, TypeError, ValueError):
        pass
    return None


def fill_style(shape: Any, theme: dict[str, str], metrics: Counter) -> dict:
    result = {'color': None, 'opacity': 100}
    try:
        f = shape.fill
        if f.type == MSO_FILL.SOLID:
            result['color'] = color_hex(f.fore_color, theme)
        elif f.type not in (None, MSO_FILL.BACKGROUND):
            metrics['unsupported_fill'] += 1
    except (ValueError, AttributeError):
        pass
    try:
        sppr = shape._element.find('p:spPr', NS)
        if sppr is not None:
            solid = sppr.find('a:solidFill', NS)
            if solid is not None:
                alpha = solid.find('.//a:alpha', NS)
                if alpha is not None:
                    result['opacity'] = round(float(alpha.get('val', '100000')) / 1000, 2)
    except Exception:
        pass
    return result


def line_style(shape: Any, theme: dict[str, str]) -> dict:
    try:
        line = shape.line
        c = color_hex(line.color, theme)
        w = pts(line.width) if line.width is not None else 0.0
        if c is None or w <= 0:
            return {'color': None, 'width': 0}
        return {'color': c, 'width': min(50, w)}
    except Exception:
        return {'color': None, 'width': 0}


def font_style(font: Any, theme: dict[str, str]) -> dict:
    try:
        clr = color_hex(font.color, theme)
    except Exception:
        clr = None
    return {
        'name': font.name or '',
        'size': round(font.size.pt, 3) if font.size is not None else None,
        'bold': font.bold if font.bold is not None else None,
        'italic': font.italic if font.italic is not None else None,
        'color': clr,
    }


def paragraph_alignment(para: Any) -> str:
    if para.alignment == PP_ALIGN.CENTER:
        return 'center'
    if para.alignment == PP_ALIGN.RIGHT:
        return 'right'
    if para.alignment == PP_ALIGN.JUSTIFY:
        return 'justify'
    return 'left'


def text_payload(sh: Any, theme: dict[str, str]) -> dict | None:
    try:
        if not sh.has_text_frame or not sh.text_frame.text.strip():
            return None
    except Exception:
        return None
    tf = sh.text_frame
    paragraphs = []
    texts = []
    for para in tf.paragraphs:
        t = para.text.replace('\v', '\n')
        texts.append(t)
        pf = font_style(para.runs[0].font if para.runs else para.font, theme)
        runs = []
        cursor = 0
        for run in para.runs:
            val = run.text.replace('\v', '\n')
            idx = t.find(val, cursor) if val else cursor
            if idx < 0:
                idx = cursor
            if val:
                runs.append({'start': idx, 'length': len(val), 'font': font_style(run.font, theme)})
            cursor = max(cursor, idx + len(val))
        paragraphs.append({'alignment': paragraph_alignment(para), 'font': pf, 'runs': runs})
    anchor = 'top'
    if tf.vertical_anchor == MSO_ANCHOR.MIDDLE:
        anchor = 'middle'
    if tf.vertical_anchor == MSO_ANCHOR.BOTTOM:
        anchor = 'bottom'
    return {
        'text': '\r'.join(texts),
        'paragraphs': paragraphs,
        'anchor': anchor,
        'insets': [pts(tf.margin_top), pts(tf.margin_left), pts(tf.margin_bottom), pts(tf.margin_right)],
    }


class AssetStore:
    def __init__(self, root: Path):
        self.root = root
        self.cache = {}
        self.root.mkdir(parents=True, exist_ok=True)

    def save_picture(self, image: Any, crop: tuple[float, float, float, float]) -> str:
        raw = image.blob
        ext = image.ext.lower().strip('.')
        try:
            left, top, right, bottom = crop
            needs_crop = any(abs(c) > 1e-6 for c in crop)
        except Exception:
            needs_crop = False
            left = top = right = bottom = 0
        digest = hashlib.sha256(raw + repr(crop).encode('ascii')).hexdigest()[:20]
        if digest in self.cache:
            return self.cache[digest]
        # Prefer native media when no cropping is necessary.
        if ext in ('jpeg', 'jpg', 'png', 'svg', 'emf', 'wmf') and not needs_crop:
            out_ext = 'jpg' if ext in ('jpg', 'jpeg') else 'png'
            converted = raw
        else:
            try:
                if ext == 'svg':
                    import cairosvg
                    raw = cairosvg.svg2png(bytestring=raw)
                with Image.open(io.BytesIO(raw)) as original:
                    im = original.copy()
                if needs_crop:
                    w, h = im.size
                    l = max(0, min(w - 1, int(round(max(0, left) * w))))
                    t = max(0, min(h - 1, int(round(max(0, top) * h))))
                    r = max(l + 1, min(w, int(round((1 - max(0, right)) * w))))
                    b = max(t + 1, min(h, int(round((1 - max(0, bottom)) * h))))
                    im = im.crop((l, t, r, b))
                out = io.BytesIO()
                if im.mode in ('RGBA', 'LA') or 'transparency' in im.info:
                    im.save(out, format='PNG')
                    out_ext = 'png'
                else:
                    im.convert('RGB').save(out, format='JPEG', quality=96, subsampling=0)
                    out_ext = 'jpg'
                converted = out.getvalue()
            except Exception as ex:
                raise RuntimeError('Cannot read PPTX image (%s): %s' % (ext, ex)) from ex
        asset_name = f'assets/{digest}.{out_ext}'
        (self.root.parent / asset_name).write_bytes(converted)
        self.cache[digest] = asset_name
        return asset_name


def geom_of(shape: Any, transform: tuple[float, float, float, float] | None = None) -> dict:
    x, y, w, h = pts(shape.left), pts(shape.top), pts(shape.width), pts(shape.height)
    if transform is not None:
        ox, oy, sx, sy = transform
        x, y, w, h = ox + x * sx, oy + y * sy, w * sx, h * sy
    return {'x': round(x, 4), 'y': round(y, 4), 'w': max(0.01, round(w, 4)),
            'h': max(0.01, round(h, 4)), 'rotation': round(float(shape.rotation or 0), 3)}


def ppt_shape_kind(shape: Any) -> str:
    pgs = shape._element.xpath('./p:spPr/a:prstGeom')
    if pgs:
        return pgs[0].get('prst', 'rect')
    return 'rect'


def table_elements(shape: Any, theme: dict, transform: tuple | None, metrics: Counter) -> list[dict]:
    box = geom_of(shape, transform)
    out = []
    x = box['x']
    for ci, col in enumerate(shape.table.columns):
        y = box['y']
        cw = pts(col.width) * (box['w'] / max(pts(shape.width), 1))
        for ri, row in enumerate(shape.table.rows):
            ch = pts(row.height) * (box['h'] / max(pts(shape.height), 1))
            cell = shape.table.cell(ri, ci)
            core = {'name': f'Table {ri + 1}:{ci + 1}', 'x': x, 'y': y, 'w': cw, 'h': ch,
                    'rotation': 0, 'kind': 'rect', 'fill': {'color': None, 'opacity': 100},
                    'stroke': {'color': 'CCD7E6', 'width': 0.5}}
            try:
                if cell.fill.type == MSO_FILL.SOLID:
                    core['fill']['color'] = color_hex(cell.fill.fore_color, theme)
            except Exception:
                pass
            out.append(core)
            if cell.text.strip():
                st = {'text': cell.text.replace('\v', '\n'), 'insets': [3, 4, 3, 4],
                      'anchor': 'middle', 'paragraphs': []}
                for p in cell.text_frame.paragraphs:
                    st['paragraphs'].append({'alignment': paragraph_alignment(p),
                          'font': font_style(p.runs[0].font if p.runs else p.font, theme), 'runs': []})
                out.append({'kind': 'text', 'name': core['name'] + ' Text', 'x': x + 1, 'y': y + 1,
                            'w': max(1, cw - 2), 'h': max(1, ch - 2), 'rotation': 0, 'text': st})
            y += ch
        x += cw
    metrics['tables_expanded'] += 1
    return out


def get_group_transform(shape: Any, parent_transform: tuple | None) -> tuple[float, float, float, float]:
    g = geom_of(shape, parent_transform)
    xfrm = shape._element.xpath('./p:grpSpPr/a:xfrm')
    if xfrm:
        ch_off = xfrm[0].find('a:chOff', NS)
        ch_ext = xfrm[0].find('a:chExt', NS)
        if ch_off is not None and ch_ext is not None:
            x0 = pts(int(ch_off.get('x', '0')))
            y0 = pts(int(ch_off.get('y', '0')))
            ww = max(0.0001, pts(int(ch_ext.get('cx', '1'))))
            hh = max(0.0001, pts(int(ch_ext.get('cy', '1'))))
            sx = g['w'] / ww
            sy = g['h'] / hh
            return (g['x'] - x0 * sx, g['y'] - y0 * sy, sx, sy)
    return (g['x'], g['y'], 1, 1)


def shape_elements(shape: Any, theme: dict, store: AssetStore, metrics: Counter,
                   transform: tuple | None = None) -> list[dict]:
    if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
        out = []
        child_transform = get_group_transform(shape, transform)
        for sub in shape.shapes:
            out.extend(shape_elements(sub, theme, store, metrics, child_transform))
        return out
    if shape.shape_type == MSO_SHAPE_TYPE.TABLE:
        return table_elements(shape, theme, transform, metrics)
    box = geom_of(shape, transform)
    name = shape.name or 'PowerPoint Element'
    if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
        try:
            crop = (float(shape.crop_left), float(shape.crop_top),
                    float(shape.crop_right), float(shape.crop_bottom))
            path = store.save_picture(shape.image, crop)
            metrics['images'] += 1
            return [dict(kind='image', name=name, path=path, **box)]
        except Exception as ex:
            metrics['images_failed'] += 1
            print('  image skipped:', ex, file=sys.stderr)
            return []
    if shape.shape_type == MSO_SHAPE_TYPE.LINE:
        metrics['lines'] += 1
        return [dict(kind='line', name=name, stroke=line_style(shape, theme), **box)]
    kind = ppt_shape_kind(shape)
    payload = []
    if kind in ('line', 'straightConnector1', 'bentConnector2'):
        payload.append(dict(kind='line', name=name, stroke=line_style(shape, theme), **box))
        metrics['lines'] += 1
    else:
        if kind not in ('rect', 'roundRect', 'ellipse', 'oval'):
            metrics['unsupported_shapes'] += 1
            kind = 'rect'
        fill = fill_style(shape, theme, metrics)
        stroke = line_style(shape, theme)
        if fill['color'] is not None or stroke['color'] is not None:
            payload.append(dict(kind='ellipse' if kind in ('ellipse', 'oval') else 'rect',
                           rounded=(kind == 'roundRect'), name=name, fill=fill, stroke=stroke, **box))
            metrics['shapes'] += 1
    if shape.has_text_frame:
        tp = text_payload(shape, theme)
        if tp is not None:
            payload.append(dict(kind='text', name=name, text=tp, **box))
            metrics['text_frames'] += 1
    return payload


def attach_references(manifest: dict, reference_dir: Path, output: Path) -> int:
    images = sorted((p for p in reference_dir.iterdir() if p.is_file() and p.suffix.lower() in ('.jpg','.jpeg','.png')),
                    key=lambda p: (int(re.match(r'^(\d+)', p.stem).group(1)) if re.match(r'^(\d+)', p.stem) else 99999, p.name))
    if len(images) != len(manifest['slides']):
        raise ValueError(f'Found {len(images)} reference images for {len(manifest["slides"])} slides. Need exactly one image per slide.')
    (output / 'reference').mkdir(parents=True, exist_ok=True)
    for i, file in enumerate(images):
        name = 'reference/slide_%02d%s' % (i+1, file.suffix.lower())
        shutil.copy2(file, output / name)
        manifest['slides'][i]['reference'] = name
    return len(images)


def run() -> None:
    ap = argparse.ArgumentParser(description='Prepare PPTX for native editable InDesign import')
    ap.add_argument('pptx', help='Input .pptx file')
    ap.add_argument('--out', help='Output folder (default: PPTX_NAME_InDesign_Ready)')
    ap.add_argument('--references', help='Optional directory of rendered slide JPG/PNG reference images')
    args = ap.parse_args()
    infile = Path(args.pptx).expanduser().resolve()
    if not infile.is_file() or infile.suffix.lower() != '.pptx':
        ap.error('Please provide an existing .pptx file')
    outfile = Path(args.out).expanduser().resolve() if args.out else infile.with_name(infile.stem + '_InDesign_Ready')
    outfile.mkdir(parents=True, exist_ok=True)
    prs = Presentation(str(infile))
    theme = load_theme(infile)
    store = AssetStore(outfile / 'assets')
    counts: Counter = Counter()
    manifest = {
        'format': 'pptx2indesign-v1', 'source': infile.name,
        'pageWidth': pts(prs.slide_width), 'pageHeight': pts(prs.slide_height),
        'slides': [],
    }
    notes_lines = []
    fonts_used = set()
    for number, slide in enumerate(prs.slides, 1):
        elements = []
        try:
            bgfill = slide.background.fill
            if bgfill.type == MSO_FILL.SOLID:
                bghex = color_hex(bgfill.fore_color, theme)
                if bghex:
                    elements.append({
                        'kind': 'rect', 'name': 'Slide Background',
                        'x': 0, 'y': 0,
                        'w': manifest['pageWidth'], 'h': manifest['pageHeight'],
                        'rotation': 0, 'fill': {'color': bghex, 'opacity': 100},
                        'stroke': {'color': None, 'width': 0},
                    })
        except Exception:
            pass
        for shape in slide.shapes:
            try:
                elements.extend(shape_elements(shape, theme, store, counts))
            except Exception as ex:
                counts['failed_shapes'] += 1
                print('  WARNING slide %d / %s: %s' % (number,shape.name,ex), file=sys.stderr)
        manifest['slides'].append({'number': number, 'elements': elements, 'reference': None})
        for element in elements:
            if element['kind'] == 'text':
                for paragraph in element['text']['paragraphs']:
                    name = paragraph['font'].get('name')
                    if name:
                        fonts_used.add(name)
                    for run in paragraph.get('runs', []):
                        name = run['font'].get('name')
                        if name:
                            fonts_used.add(name)
        counts['slides'] += 1
        counts['objects'] += len(elements)
        if slide.has_notes_slide:
            try:
                lines = slide.notes_slide.notes_text_frame.text.strip()
                if lines:
                    notes_lines.append(f'SLIDE {number}\n{lines}\n')
            except Exception:
                pass
        print('Slide %02d: %d editable elements' % (number, len(elements)))
    if args.references:
        count = attach_references(manifest, Path(args.references).expanduser().resolve(), outfile)
        counts['references'] = count
    (outfile / 'conversion_manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=True), encoding='utf-8')
    (outfile / 'speaker_notes.txt').write_text('\n'.join(notes_lines), encoding='utf-8')
    (outfile / 'fonts_used.txt').write_text('Fonts used in the PowerPoint:\n' + '\n'.join(sorted(fonts_used)) + '\n\nInstall these families before opening the editable InDesign document for closest matching. Font files are not included.\n', encoding='utf-8')
    report = ['PowerPoint-to-InDesign preparation report', '=' * 40,
              f'Source: {infile.name}', f'Pages: {len(prs.slides)}',
              f'Page size: {manifest["pageWidth"]} x {manifest["pageHeight"]} pt',
              ''] + [f'{k}: {counts[k]}' for k in sorted(counts)] + [
              '', 'IMPORTANT:',
              'This is an editable reconstruction, not a pixel-perfect native PPTX import.',
              'The dual-format InDesign JSX importer creates .INDD and .IDML.',
              'Linked pictures: keep the assets folder in place.',
              'If you supplied references, the InDesign script creates a hidden reference layer.',
              'Review fonts, overflow, transparency, image crop, charts and unsupported artwork.',
              'Do not deliver the converted publication before checking each page.',
              '']
    (outfile / 'conversion_report.txt').write_text('\n'.join(report), encoding='utf-8')
    print('\nReady:', outfile)
    print('Prepared for the PPTX + PDF to InDesign two-button importer:')
    print(outfile / 'conversion_manifest.json')


if __name__ == '__main__':
    run()
