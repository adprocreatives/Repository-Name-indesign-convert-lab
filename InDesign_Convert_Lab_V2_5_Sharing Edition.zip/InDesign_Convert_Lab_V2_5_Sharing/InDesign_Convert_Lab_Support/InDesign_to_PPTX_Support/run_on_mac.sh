#!/bin/bash
# BASHEER InDesign to PPTX builder, (c) 2026 adprocreatives.
# Invoked automatically by the JSX through AppleScript; no need to open .command.
set -euo pipefail
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MANIFEST="${1:-}"
if [[ -z "$MANIFEST" || ! -f "$MANIFEST" ]]; then echo 'Missing conversion manifest' >&2; exit 2; fi
OUT_DIR="$(dirname "$MANIFEST")"
LOG="$OUT_DIR/run.log"
find_node() {
  if command -v node >/dev/null 2>&1; then command -v node; return; fi
  if [[ -x /opt/homebrew/bin/node ]]; then echo /opt/homebrew/bin/node; return; fi
  if [[ -x /usr/local/bin/node ]]; then echo /usr/local/bin/node; return; fi
  local n
  n="$(find "$HOME/.nvm/versions/node" -name node -type f 2>/dev/null | sort -V | tail -1 || true)"
  if [[ -x "$n" ]]; then echo "$n"; fi
}
NODE="$(find_node || true)"
if [[ -z "$NODE" ]]; then
  echo "Node.js 18+ is required. Download from https://nodejs.org/ and reopen InDesign." >&2
  exit 3
fi
export PATH="$(dirname "$NODE"):$PATH"
if [[ ! -f "$SCRIPT_DIR/node_modules/pptxgenjs/package.json" || ! -f "$SCRIPT_DIR/node_modules/jszip/package.json" ]]; then
  if ! command -v npm >/dev/null 2>&1; then echo 'npm is missing. Install Node.js LTS from nodejs.org.' >&2; exit 4; fi
  if ! (cd "$SCRIPT_DIR" && npm install --no-audit --no-fund --omit=dev >"$LOG" 2>&1); then
    echo "Unable to install PptxGenJS dependencies. Internet required on first run. See $LOG" >&2
    exit 5
  fi
fi
if ! "$NODE" "$SCRIPT_DIR/build_pptx.js" "$MANIFEST" >"$LOG" 2>&1; then
  echo "PPTX build failed. Inspect $LOG" >&2
  exit 6
fi
grep '^BP_PPTX_READY=' "$LOG" | tail -1
