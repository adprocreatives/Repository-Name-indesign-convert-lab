#!/usr/bin/env node
'use strict';
/*
  BASHEER | InDesign to PowerPoint | PPTX Builder 1.1
  Created By Basheer Parammal - (c) 2026 adprocreatives.

  Usage: node build_pptx.js /absolute/path/to/manifest.json
  The manifest is produced by the companion InDesign ExtendScript exporter.
  Powered by PptxGenJS. Requires Node.js >= 18.
*/
const fs = require('fs');
const path = require('path');
const PptxGenJS = require('pptxgenjs');
let JSZip;
try { JSZip = require('jszip'); }
catch (_) { JSZip = require(path.join(path.dirname(require.resolve('pptxgenjs')), '..', 'node_modules', 'jszip')); }

const CREDIT = 'Created By Basheer Parammal · © 2026 adprocreatives.';
const PT_PER_INCH = 72;
function numeric(v, d = 0) { const n=Number(v); return Number.isFinite(n) ? n : d; }
function safeName(v, cap=120) { return String(v||'').replace(/[\x00-\x1f<>:\\/?*|"']/g, '_').trim().substring(0,cap) || 'InDesign_Document'; }
function rgb(v, d = '000000') { return /^[0-9A-F]{6}$/i.test(String(v||'')) ? String(v).toUpperCase() : d; }
function escapedXml(s) { return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function fileRef(root, value) {
  if (!value) return null;
  const p = path.resolve(root,String(value));
  if (!p.startsWith(path.resolve(root)+path.sep)) throw new Error(`Blocked asset path outside export root: ${value}`);
  return fs.existsSync(p) ? p : null;
}
function makeCtx(page,maxWPt,maxHPt) {
  const sw=maxWPt/72, sh=maxHPt/72;
  const factor=Math.min(1, 54/Math.max(sw,sh));
  const pageW=numeric(page.widthPt),pageH=numeric(page.heightPt);
  return {
    factor,
    scale:factor/72,
    offsetX:(maxWPt-pageW)*factor/144,
    offsetY:(maxHPt-pageH)*factor/144,
    slideW:sw*factor,slideH:sh*factor
  };
}
function rect(i,ctx) {
  const b=i.b||{};
  return {x:numeric(b.x)*ctx.scale+ctx.offsetX, y:numeric(b.y)*ctx.scale+ctx.offsetY,
    w:Math.max(0.002,numeric(b.w)*ctx.scale),h:Math.max(0.002,numeric(b.h)*ctx.scale)};
}
function shapeName(i,index) { return safeName(`${i.layer||'Layer'} | ${i.name||i.kind||'Item'} [${index+1}]`,150); }
function commonOptions(i,ctx,index) {
  const xy=rect(i,ctx), style=i.style||{};
  return {...xy,objectName:shapeName(i,index),rotate:numeric(style.rotation),
    transparency:Math.max(0,Math.min(100,100-numeric(style.opacity,100)))};
}
function fillStyle(s) {
  if (s.fill===null || typeof s.fill==='undefined') return {color:'FFFFFF',transparency:100};
  return {color:rgb(s.fill,'999999'),transparency:Math.max(0,Math.min(100,100-numeric(s.opacity,100)))};
}
function lineStyle(s) {
  if(!s.stroke || numeric(s.strokePt)<=0) return {color:'FFFFFF',transparency:100,width:0};
  return {color:rgb(s.stroke),width:Math.max(0.01,numeric(s.strokePt)),transparency:Math.max(0,100-numeric(s.opacity,100))};
}
function nativePath(points,b,ctx) {
  if(!Array.isArray(points)||points.length<3)return null;
  const local=({x,y})=>({x:(numeric(x)-numeric(b.x))*ctx.scale,y:(numeric(y)-numeric(b.y))*ctx.scale});
  const out=[local(points[0])];
  for(let z=1;z<=points.length;z++){
    const cur=points[z%points.length], prev=points[z-1], pt=local(cur);
    const ctrl1=local({x:prev.outX,y:prev.outY}),ctrl2=local({x:cur.inX,y:cur.inY});
    const p1=local(prev), p2=pt;
    if(Math.hypot(ctrl1.x-p1.x,ctrl1.y-p1.y)>0.0001 || Math.hypot(ctrl2.x-p2.x,ctrl2.y-p2.y)>0.0001)
      pt.curve={type:'cubic',x1:ctrl1.x,y1:ctrl1.y,x2:ctrl2.x,y2:ctrl2.y};
    out.push(pt);
  }
  out.push({close:true});
  return out;
}
function editableText(slide,i,ctx,index,issues) {
  const base=commonOptions(i,ctx,index), originalRuns=Array.isArray(i.runs)?i.runs:[];
  const fallback=String(i.sourceText||'');
  const runs=originalRuns.length?originalRuns:(fallback?[{text:fallback,fontFamily:'Arial',fontSize:12,color:'222222'}]:[]);
  if(!runs.length){issues.push('Empty text frame omitted: '+base.objectName);return 0;}
  const s=i.style||{};
  const parts=runs.filter(r=>String(r.text||'').length).map(r=>{
    const opts={fontFace:String(r.fontFamily||'Arial'),
      fontSize:Math.max(1,numeric(r.fontSize,12)*ctx.factor),color:rgb(r.color,'222222'),
      bold:!!r.bold,italic:!!r.italic};
    if(numeric(r.tracking)!==0)opts.charSpacing=numeric(r.tracking)*numeric(r.fontSize,12)/1000;
    return {text:String(r.text).replace(/\r\n?/g,'\n'),options:opts};
  });
  if(!parts.length){issues.push('No valid text segments: '+base.objectName);return 0;}
  const margin=Array.isArray(i.padding)?i.padding:[0,0,0,0];
  const props={...base,
    // PptxGenJS margins are points, not inches.
    margin:[0,1,2,3].map(k=>numeric(margin[k],0)*ctx.factor),
    valign:i.valign==='mid'?'mid':(i.valign||'top'),align:i.align||'left',
    fontSize:Math.max(1,numeric(runs[0].fontSize,12)*ctx.factor),
    fontFace:runs[0].fontFamily||'Arial',
    breakLine:false,fit:'shrink'};
  // Text-frame background is inserted immediately before the text itself.
  if(s.fill || s.gradient || s.stroke){
    slide.addShape('rect',{...base,objectName:`${base.objectName} [frame]`,
      fill:fillStyle(s),line:lineStyle(s)});
  }
  // Text is emitted in a dedicated late pass, above opaque card and image objects.
  slide.addText(parts,props);
  if(i.overset)issues.push('Overset text in source: '+base.objectName);
  return parts.reduce((n,p)=>n+p.text.length,0);
}
function editableShape(pptx,slide,i,ctx,index,gradQueue,issues,pageNum) {
  const s=i.style||{},base=commonOptions(i,ctx,index);
  let st='rect';
  if(i.kind==='ellipse')st='ellipse';else if(i.kind==='roundrect')st='roundRect';else if(i.kind==='line')st='line';
  else if(i.kind==='path')st=pptx.ShapeType.custGeom||'custGeom';
  const options={...base,fill:fillStyle(s),line:lineStyle(s)};
  if(i.kind==='line'){
    options.fill={color:'FFFFFF',transparency:100};
    // InDesign line could run in reverse diagonal; item bounds only yields approximate direction.
    options.w=Math.max(0.001,options.w);
  }
  if(i.kind==='path'){
    const pts=nativePath(i.vertices,i.b,ctx);
    if(!pts){issues.push('Custom path omitted: '+base.objectName);return;}
    options.points=pts;
  }
  try {slide.addShape(st,options);}catch(e){issues.push('Editable shape failed '+base.objectName+': '+e);return;}
  if(s.gradient && s.gradient.kind==='linear' && Array.isArray(s.gradient.stops)) {
    gradQueue.push({pageNum,name:base.objectName,stops:s.gradient.stops,angle:numeric(s.gradient.angle,0),opacity:numeric(s.opacity,100)});
  }
}
function placeImage(slide,i,ctx,index,root,issues) {
  const f=fileRef(root,i.asset);
  if(!f){issues.push('Missing picture '+(i.name||'')+': '+(i.asset||'(none)'));return;}
  const base=commonOptions(i,ctx,index);
  // Item PNGs already include rotation, crop and masks; do not rotate twice.
  try{slide.addImage({path:f,...base,rotate:0,altText:String(i.name||''),
    transparency:base.transparency});}catch(e){issues.push('Picture could not be embedded '+(i.name||'')+': '+e);}
}
function stopXML(stop,opacity){
  const pos=Math.round(Math.max(0,Math.min(100,numeric(stop.pos,0)))*1000);
  const alpha=Math.round(Math.max(0,Math.min(100,opacity))*1000);
  return `<a:gs pos="${pos}"><a:srgbClr val="${rgb(stop.color,'777777')}">${alpha<100000?`<a:alpha val="${alpha}"/>`:''}</a:srgbClr></a:gs>`;
}
function gradientXML(grad){
  const stops=grad.stops.slice().sort((a,b)=>numeric(a.pos)-numeric(b.pos));
  if(!stops.length)return '';
  const angle=(numeric(grad.angle)%360+360)%360;
  return `<a:gradFill rotWithShape="1"><a:gsLst>${stops.map(s=>stopXML(s,grad.opacity)).join('')}</a:gsLst><a:lin ang="${Math.round(angle*60000)}" scaled="1"/></a:gradFill>`;
}
async function patchNativeGradients(pptxPath,gradQueue){
  if(!gradQueue.length)return 0;
  const zip=await JSZip.loadAsync(fs.readFileSync(pptxPath));
  let count=0;
  const bySlide={};
  gradQueue.forEach(g=>(bySlide[g.pageNum]??=[]).push(g));
  for(const page of Object.keys(bySlide)){
    const xmlPath=`ppt/slides/slide${page}.xml`;
    const entry=zip.file(xmlPath);if(!entry)continue;
    let xml=await entry.async('string');
    const variants=bySlide[page];
    // Only patch shape properties for the shape identified by its unique objectName.
    xml=xml.replace(/<p:sp>[\s\S]*?<\/p:sp>/g,sp=>{
      const m=sp.match(/<p:cNvPr\b[^>]*\bname="([^"]+)"/);
      if(!m)return sp;
      const name=m[1].replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&lt;/g,'<').replace(/&gt;/g,'>');
      const g=variants.find(v=>v.name===name);if(!g)return sp;
      const gradXml=gradientXML(g);if(!gradXml)return sp;
      const replaced=sp.replace(/<p:spPr>([\s\S]*?)<\/p:spPr>/,(_,body)=>{
        let clean=body.replace(/<a:solidFill>[\s\S]*?<\/a:solidFill>/,'').replace(/<a:noFill\s*\/>/,'');
        const transEnd=clean.search(/<a:(ln|effectLst|effectDag|scene3d|sp3d)\b/);
        if(transEnd>=0)clean=clean.slice(0,transEnd)+gradXml+clean.slice(transEnd);
        else clean+=gradXml;
        return `<p:spPr>${clean}</p:spPr>`;
      });
      if(replaced!==sp)count++;
      return replaced;
    });
    zip.file(xmlPath,xml);
  }
  await fs.promises.writeFile(pptxPath,await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE',compressionOptions:{level:6}}));
  return count;
}
async function createVisualReference(root,manifest,output,maxWPt,maxHPt){
  const pptx=new PptxGenJS();
  const ctx0=makeCtx(manifest.pages[0],maxWPt,maxHPt);
  pptx.defineLayout({name:'SOURCED',width:ctx0.slideW,height:ctx0.slideH});pptx.layout='SOURCED';
  pptx.author='Basheer Parammal';pptx.company='adprocreatives';
  pptx.subject='Unedited page images for visual comparison only.';
  pptx.title=manifest.title+' - Source Reference';
  for(const p of manifest.pages){
    const slide=pptx.addSlide();slide.background={color:'FFFFFF'};
    const ref=fileRef(root,p.reference);
    if(ref){let ctx=makeCtx(p,maxWPt,maxHPt);slide.addImage({path:ref,x:ctx.offsetX,y:ctx.offsetY,
      w:p.widthPt*ctx.scale,h:p.heightPt*ctx.scale,objectName:'Original page '+p.number});}
    else slide.addText('No reference image available for page '+p.number,{x:1,y:1,w:5,h:1,fontSize:22});
    slide.addNotes(`Visual reference, page ${p.number}. ${CREDIT}`);
  }
  await pptx.writeFile({fileName:output});
}
async function main(){
  const file=process.argv[2];if(!file)throw new Error('Usage: node build_pptx.js manifest.json');
  const manifestPath=path.resolve(file), root=path.dirname(manifestPath);
  const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
  if(manifest.format!=='indesign-to-pptx-v1'||!manifest.pages||!manifest.pages.length)throw new Error('Not a valid InDesign-to-PPTX v1 manifest');
  const maxWPt=Math.max(...manifest.pages.map(p=>numeric(p.widthPt)));
  const maxHPt=Math.max(...manifest.pages.map(p=>numeric(p.heightPt)));
  if(maxWPt<=0||maxHPt<=0)throw new Error('Invalid InDesign dimensions');
  const pptx=new PptxGenJS(), dimensions=makeCtx(manifest.pages[0],maxWPt,maxHPt);
  pptx.defineLayout({name:'INDESIGN',width:dimensions.slideW,height:dimensions.slideH});pptx.layout='INDESIGN';
  pptx.author='Basheer Parammal';pptx.company='adprocreatives';
  pptx.subject='InDesign document reconstructed as selectable editable PowerPoint objects.';
  pptx.title=String(manifest.title||'InDesign Document')+' - Editable';
  pptx.lang='en-US';
  const fontList=Object.values(manifest.fonts||{}).filter(Boolean);
  pptx.theme={headFontFace:fontList[0]||'Aptos Display',bodyFontFace:fontList[0]||'Aptos',lang:'en-US'};
  const gradientQueue=[],issues=Array.isArray(manifest.warnings)?manifest.warnings.slice():[];
  const textStats={expectedFrames:0,createdFrames:0,expectedChars:0,createdChars:0,sourceFound:numeric((manifest.diagnostics||{}).textFramesFound)};
  const sourceExported=numeric((manifest.diagnostics||{}).textFramesExported);
  if(textStats.sourceFound>0 && sourceExported===0)
    throw new Error('InDesign contains '+textStats.sourceFound+' text frames, but none were extracted. See TEXT_EXPORT_AUDIT.txt.');
  for(let pg=0;pg<manifest.pages.length;pg++){
    const p=manifest.pages[pg],ctx=makeCtx(p,maxWPt,maxHPt),slide=pptx.addSlide();
    slide.background={color:'FFFFFF'};
    if(Math.abs(p.widthPt-maxWPt)>0.01||Math.abs(p.heightPt-maxHPt)>0.01)issues.push('Mixed page size: page '+p.number+' centered on largest-page slide size.');
    const items=Array.isArray(p.items)?p.items:[];
    // Pass 1: all non-text shapes, images and page backgrounds.
    // Pass 2: text. Avoids text being hidden by misordered opaque InDesign fills.
    for(let i=0;i<items.length;i++){
      const item=items[i];if(item.kind==='text')continue;
      try{
        if(item.kind==='image')placeImage(slide,item,ctx,i,root,issues);
        else if(['rect','roundrect','ellipse','path','line'].includes(item.kind))editableShape(pptx,slide,item,ctx,i,gradientQueue,issues,pg+1);
        else issues.push('Unrecognized object type page '+p.number+': '+item.kind);
      }catch(e){issues.push('Page '+p.number+', item '+i+': '+e.message);}
    }
    for(let i=0;i<items.length;i++){
      const item=items[i];if(item.kind!=='text')continue;
      textStats.expectedFrames++;
      textStats.expectedChars+=Array.isArray(item.runs)?item.runs.reduce((n,r)=>n+String(r.text||'').length,0):0;
      try{
        const n=editableText(slide,item,ctx,i,issues);
        if(n>0){textStats.createdFrames++;textStats.createdChars+=n;}
      }catch(e){issues.push('Page '+p.number+', TEXT '+i+': '+e.message);}
    }
    const notes=[`Source InDesign page ${p.number} (${p.name}).`,
      `Object layers are approximated in PowerPoint paint order; use Home > Arrange > Selection Pane to select individual objects.`,
      `Fonts referenced by name require installation/activation on the recipient computer.`,CREDIT];
    slide.addNotes(notes.join('\n'));
  }
  const title=safeName(String(manifest.title).replace(/\.(indd|idml)$/i,''),90);
  const editable=path.join(root,title+'_Editable.pptx');
  const ref=path.join(root,title+'_Visual_Reference.pptx');
  if(textStats.expectedFrames>0 && textStats.createdFrames===0)
    throw new Error('All '+textStats.expectedFrames+' text frames failed to export. See the manifest and report.');
  await pptx.writeFile({fileName:editable});
  const patched=await patchNativeGradients(editable,gradientQueue);
  const zipCheck=await JSZip.loadAsync(fs.readFileSync(editable));
  let renderedTextNodes=0,renderedTextChars=0;
  for(const key of Object.keys(zipCheck.files)){
    if(!/^ppt\/slides\/slide\d+\.xml$/.test(key))continue;
    const xml=await zipCheck.file(key).async('string');
    const found=xml.match(/<a:t(?:\s[^>]*)?>[\s\S]*?<\/a:t>/g)||[];
    renderedTextNodes+=found.length;
    renderedTextChars+=found.join('').replace(/<[^>]*>/g,'').length;
  }
  if(textStats.createdChars>0 && renderedTextNodes===0)
    throw new Error('Text was extracted but none was written to PPTX XML. Conversion stopped.');
  if(textStats.expectedFrames!==textStats.createdFrames)
    issues.push('Text frames: expected '+textStats.expectedFrames+', created '+textStats.createdFrames+'.');
  if(manifest.pages.some(p=>p.reference))await createVisualReference(root,manifest,ref,maxWPt,maxHPt);
  const report=[`BASHEER | InDesign to PPTX Converter`,CREDIT,``,
    `Document: ${manifest.title}`,`Slides: ${manifest.pages.length}`,
    `Text frames found by exporter: ${textStats.sourceFound}`,
    `Text frames in manifest: ${textStats.expectedFrames}`,
    `Editable text frames created: ${textStats.createdFrames}`,
    `Characters in manifest: ${textStats.expectedChars}`,
    `Characters written by builder: ${textStats.createdChars}`,
    `PPTX XML text nodes: ${renderedTextNodes}`,
    `Visible-text fidelity: text above other page artwork to prevent concealment`,
    `Editable native gradient fills: ${patched} of ${gradientQueue.length} candidates`,
    `Editable PowerPoint: ${editable}`,`Reference deck: ${fs.existsSync(ref)?ref:'Not created (source reference PNGs unavailable)'}`,``,
    `Known limitations: InDesign-specific blend modes, mesh gradients, shadow/feather effects, and some complex groups`,
    `are individually rasterized into transparent PNGs instead of native PowerPoint shapes.`,
    `Fonts are not embedded. Install or activate the original font families for exact rendering.`,
    `Source .INDD/.IDML is never changed.`,``,'Warnings:',...(issues.length?issues:['(none)'])].join('\n');
  fs.writeFileSync(path.join(root,'CONVERSION_REPORT.txt'),report,'utf8');
  console.log('BP_PPTX_READY='+editable);
  console.log('BP_SLIDE_COUNT='+manifest.pages.length);
  console.log('BP_GRADIENTS='+patched);
  console.log('BP_TEXT_FRAMES='+textStats.createdFrames);
  console.log('BP_TEXT_CHARS='+textStats.createdChars);
  console.log('BP_TEXT_NODES='+renderedTextNodes);
}
main().catch(err=>{console.error('Conversion failed:',err.stack||err);process.exitCode=1;});
