## v2.5 - Final interface polish
- Removed "Basheer |" from the title bar in the main and review dialogs.
- Reduced the creator credit display size from 10 pt to 8 pt in both dialogs.
- Preserved the author attribution, engine files, and all conversion behavior.

# InDesign Convert Lab

## v2.5 (2026-10-29)
- Combined the InDesign-to-PPTX v1.1 and PPTX/PDF-to-InDesign v3.4 engines.
- One script installed in the InDesign Scripts panel; nested helpers remain bundled.
- New centered four-choice ScriptUI selector with explicit **Review Conversion** step.
- Preflight file and support-folder validation before beginning conversion.
- For INDD/IDML → PPTX, retains selectable page-reference PPTX and 150/200/300 dpi fallback settings.
- Retains automatic `.indd` + `.idml` output, independent photo assets, linked PDF vector shadings, paragraph extraction, and font reports in the other direction.
- Keeps creator attribution at a smaller size in the window and reports.

**Note:** Both bundled engines are versioned independently; the Lab version does not supersede their conversion limitations.
